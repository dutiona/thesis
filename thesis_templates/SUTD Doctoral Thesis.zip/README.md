This is a template for LaTeX thesis (M.Sc. or PhD) at SUTD.

This template was adapted by Martin Ochoa based on a template downloaded from:

http://www.LaTeXTemplates.com

 Version 2.x major modifications by:
 Vel (vel@latextemplates.com)

 which in turn was based on a template by:
 Steve Gunn (http://users.ecs.soton.ac.uk/srg/softwaretools/document/templates/)
 Sunil Patel (http://www.sunilpatel.co.uk/thesis-template/)
 

 Template license:
 CC BY-NC-SA 3.0 (http://creativecommons.org/licenses/by-nc-sa/3.0/)
